# 地狱难度 · 祈愿重随战痕

## 功能
- 仅在 **地狱难度** 的「混沌战痕」界面生效
- 在「开始」按钮上方增加 **祈愿** 按钮（外观克隆自开始）
- 点击后重新随机三个战痕

## 安装
本补丁依赖 BepInEx（已放在游戏根目录）。

1. 确认游戏根目录有：`winhttp.dll`、`doorstop_config.ini`、`BepInEx\`、`dotnet\`
2. 本 Mod 文件位于：`mods\HellPrayReroll\HellPrayReroll.dll`
3. 同时会加载：`BepInEx\plugins\HellPrayReroll.dll`（与上面为同一文件的副本）
4. **完全退出游戏后重新启动**（首次启用 BepInEx 可能稍慢）

## 联机
合作模式请房主与队员都安装同一版本，避免战痕不同步。

## 卸载
删除 `BepInEx\plugins\HellPrayReroll.dll` 与 `mods\HellPrayReroll\`，或去掉整个 BepInEx/doorstop。

## 日志
问题排查看：`BepInEx\LogOutput.txt`
